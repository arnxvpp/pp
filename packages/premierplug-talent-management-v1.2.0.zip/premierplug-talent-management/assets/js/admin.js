/**
 * PremierPlug Talent Management - Admin JavaScript
 */

(function($) {
    'use strict';

    $(document).ready(function() {

        // Admin functionality can be added here
        console.log('PremierPlug Talent Management Admin JS loaded');

    });

})(jQuery);
